export declare const capitalizeFirstLetter: (text: string) => string;
