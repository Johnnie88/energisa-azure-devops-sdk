export declare const getHostUrl: (localStorageKey?: string, includeOrg?: boolean) => Promise<string | undefined>;
