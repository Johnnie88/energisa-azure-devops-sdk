/// <reference types="react" />
export declare function showRootComponent(component: React.ReactElement<any>, target: string): void;
