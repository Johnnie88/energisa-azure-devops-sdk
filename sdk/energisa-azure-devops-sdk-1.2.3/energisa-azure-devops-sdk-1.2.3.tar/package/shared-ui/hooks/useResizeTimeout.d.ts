export declare function useResizeTimeout(interval: number): void;
