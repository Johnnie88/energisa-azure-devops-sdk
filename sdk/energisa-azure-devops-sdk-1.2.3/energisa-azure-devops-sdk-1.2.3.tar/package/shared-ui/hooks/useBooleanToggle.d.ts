/// <reference types="react" />
export declare function useBooleanToggle(initialValue?: boolean): readonly [boolean, (value?: React.SetStateAction<boolean> | undefined) => void];
