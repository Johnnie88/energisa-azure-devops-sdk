export interface BoardColumnDisplayProps {
    color: string;
    text: string;
}
export declare const BoardColumnDisplay: ({ color, text }: BoardColumnDisplayProps) => React.ReactElement;
