export interface WorkItemStateDisplayProps {
    color: string;
    text: string;
}
export declare const WorkItemStateDisplay: ({ color, text }: WorkItemStateDisplayProps) => React.ReactElement;
