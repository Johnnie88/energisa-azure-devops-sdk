export interface LoadingSectionProps {
    isLoading: boolean;
    text: string;
}
export declare const LoadingSection: ({ isLoading, text }: LoadingSectionProps) => React.ReactElement;
